MySqlBackup.DLL
v2.1

MySql.Data.DLL
v8.0.13

Google.Protobuf
v3.5.1