MySqlBackup.DLL
v2.1

MySql.Data.DLL
v6.9.8