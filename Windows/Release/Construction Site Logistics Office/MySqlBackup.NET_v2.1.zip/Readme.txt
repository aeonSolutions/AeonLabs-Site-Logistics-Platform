Question:
The binary build for my platform is not available?

Answer:
You can go to Github, download the source code and merge it directly into your project.
Bingo! You can now use the library in ANY platform you like.

https://github.com/MySqlBackupNET/MySqlBackup.Net